import numpy as np
import matplotlib.pyplot as plt
from scipy import integrate
from scipy import interpolate


i= np.loadtxt("data.txt")
x=[]
y=[]

for j in range(len(i)):
        x=x+[i[j][0]]
        y=y+[i[j][1]]
        
#scatter plot
plt.figure(1)
plt.scatter(x, y,c="r",label="scatter plot")

 
#spline interpolation
z=np.arange(-1.5,1.6,0.1)
f=interpolate.CubicSpline(x,y)   
plt.plot(z,f(z), c="g",label="interpolation line plot")
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.legend(loc="upper right")
plt.title("interpolation for given data")
plt.show()


#Root finding
n=100 # iterations for bisection
a=-1
b=1
for i in range(n):
    #Bisection Method
    if f(0.5*(a+b))==0:
        break
    if f(a)*f(0.5*(a+b))<0:
        b=0.5*(a+b)
    elif f(b)*f(0.5*(a+b))<0:
            a=0.5*(a+b)

r=0.5*(a+b)

print("root is",r)