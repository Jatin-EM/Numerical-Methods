import numpy as np
import matplotlib.pyplot as plt
from scipy import integrate
from scipy import interpolate
       

def f(x,y):
    f=np.sqrt(4-x**2-y**2)
    return(f)

n=100 #iterations
ax=-1 #x lower lim
ay=-1 #y lower lim
bx=1  #x upper lim
by=1  #x upper lim
ii=0 #initialising

#Double integration using midpoint rule
hx=(bx-ax)/(n)
hy=(by-ay)/(n)
for i in range(n):
    for j in range(n):
        ii=ii+hx*hy*f(ax+(0.5+i)*hx,ay+(0.5+j)*hy)

print("value of integral is ",ii)
        

