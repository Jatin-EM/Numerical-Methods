import numpy as np
import matplotlib.pyplot as plt
from scipy import integrate
from scipy import interpolate

def ar_circ(r):
    
    def f(x,r):
        y=np.sqrt(r**2-x**2)
        return(y)
    
    #Numerical integration- Mid point rule
    a=-r #lower limit of integration
    b=r #upper limit of integration
    n= 1000 # iterations
    i_mp=0 #integral

    for j in range(n):
        h=(b-a)/(n)
        i_mp=i_mp+h*f(a+(0.5+j)*h,r)
    ar=2*i_mp
    
    return(ar)

# Area plot For radius 5 to 50
r=np.arange(5,55,5)
ar=ar_circ(r)

#Spline Interpolation
aspline=interpolate.CubicSpline(r,ar)

z=np.arange(0,51,1)

plt.figure(1)
plt.plot(z,aspline(z),"r", label="Interpolation")
plt.plot(r,ar,"o", label="area on r=5,10...50")
plt.legend(loc="upper right")
plt.xlabel("radius")
plt.ylabel("interpolated area")
plt.title("spline interpolation of area of circle")
plt.show()

print("Area at r=13 is",aspline(13), "through spline interpolation")